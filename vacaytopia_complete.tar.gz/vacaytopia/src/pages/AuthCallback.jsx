import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'

export default function AuthCallback() {
  const navigate = useNavigate()

  useEffect(() => {
    // Supabase parses the token from the URL hash automatically.
    // We just need to wait for the session to be established, then redirect.
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        navigate('/browse', { replace: true })
      } else {
        navigate('/auth', { replace: true })
      }
    })
  }, [navigate])

  return (
    <div className="min-h-screen flex items-center justify-center" style={{ background: 'var(--bg)' }}>
      <div className="text-center">
        <div className="font-display font-black text-3xl text-blue-brand mb-3">
          Vacay<span className="text-gold-brand">topia</span>
        </div>
        <div className="text-sm text-gray-400">Signing you in...</div>
      </div>
    </div>
  )
}
